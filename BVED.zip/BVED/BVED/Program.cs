﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BVED
{
    class Program
    {
        static void Main(string[] args)
        {
            // Options
            const int colorBytes = 24;
            const int byteArrayLength = colorBytes * 100;
            const int imageWidth = 1000;
            const int imageHeight = 1000;
            String inputFilePath = @"C:\Users\jubartels\Downloads\VSCodeSetup-1.8.1.exe";
            String outputFilePath = @"C:\Users\jubartels\Downloads\output_{0}.png";

            // Var
            Bitmap bitmap = new Bitmap(imageWidth, imageHeight);
            FastBitmap fastBitmap = new FastBitmap(bitmap);
            fastBitmap.Lock();
            fastBitmap.Clear(Color.FromArgb(255, 0, 0, 0));
            int part = 0;
            int x = 0;
            int y = 0;

            using (FileStream stream = new FileStream(inputFilePath, FileMode.Open))
            {
                BinaryReader binReader = new BinaryReader(stream);
                String previousPercent = "";

                while (stream.Position < stream.Length)
                {
                    // Bytes
                    byte[] byteArray = binReader.ReadBytes(byteArrayLength);
                    int numberOfMissingBytes = byteArrayLength - byteArray.Length;
                    if (numberOfMissingBytes != 0)
                    {
                        Array.Resize(ref byteArray, byteArrayLength);
                        for (int i = byteArray.Length - 1; i < byteArrayLength; i++)
                            byteArray[i] = 0;
                    }

                    // Image
                    for (int i = 0; i < byteArrayLength - colorBytes/8; i += colorBytes / 8)
                    {
                        Color c = Color.FromArgb(255, byteArray[i], byteArray[i + 1], byteArray[i + 2]);
                        fastBitmap.SetPixel(x, y, c);

                        if(x < imageWidth-1)
                        {
                            x++;
                        }
                        else
                        {
                            x = 0;
                            y++;

                            if(y >= imageHeight - 1)
                            {
                                fastBitmap.Unlock();
                                bitmap.Save(String.Format(outputFilePath, part), ImageFormat.Png);
                                part++;

                                x = 0;
                                y = 0;
                                bitmap = new Bitmap(imageWidth, imageHeight);
                                fastBitmap = new FastBitmap(bitmap);
                                fastBitmap.Lock();
                                fastBitmap.Clear(Color.FromArgb(255, 0, 0, 0));
                            }
                        }
                    }

                    // Info
                    String percent = String.Format("{0:0.00}%", 1.0 * stream.Position / stream.Length * 100);
                    if (percent != previousPercent) {
                        Console.WriteLine(percent);
                        previousPercent = percent;
                    }
                }
            }
            fastBitmap.Unlock();
            bitmap.Save(String.Format(outputFilePath, part), ImageFormat.Png);
            Console.WriteLine("Finished");
        }
    }
}
